# wp-experience-api
Way to send basic xAPI statements from WordPress for various events.
