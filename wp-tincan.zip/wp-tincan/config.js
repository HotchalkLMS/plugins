//globals: equal, responseText, statement, ok, deepEqual, QUnit, module, asyncTest, Util, start, golfStatements, console
/*jslint bitwise: true, browser: true, plusplus: true, maxerr: 50, indent: 4 */
function Config() {
	"use strict";
}
Config.endpoint = " 	https://cloud.scorm.com/tc/UOTFDJF2DG/sandbox/";
Config.authUser = "Je1BkJBaEa1Hwe1fS9k";
Config.authPassword = "ubVA7v76K8FU9XZUwj4";
Config.actor = { "mbox":["admin@sagedreaddesigns.com"], "name":["Nathan Martin"] };
Config.registration = "<registration-uuid>";
