	
		function Config() {
	"use strict";
}
if(vars.course != null){
if(vars.course != " "){
document.cookie = "currentcourse="+vars.course+"; path=/";
}
}