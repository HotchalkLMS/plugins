const { __ } = wp.i18n;

const {
	assign
} = lodash;

const {
	addFilter
} = wp.hooks;

const {
	PanelBody,
	TextControl,
    SelectControl
} = wp.components;

const {
	Fragment
} = wp.element;

const {
	createHigherOrderComponent
} = wp.compose;

const {
    InspectorControls
} = wp.editor;

export const addToolkitCourseDashboardSettings = createHigherOrderComponent( ( BlockEdit ) => {
    return ( props ) => {
        // Check if we have to do something
        if ( props.name == 'uncanny-toolkit-pro/learn-dash-my-courses' && props.isSelected ){
            return (
                <Fragment>
                    <BlockEdit { ...props } />
                    <InspectorControls>

                        <PanelBody title={ __( 'Dashboard Content' ) }>
                            <TextControl label={ __( 'category' ) } value={ props.attributes.category } type='string' onChange={ ( value ) => { props.setAttributes({ category: value }); }} />
                            <TextControl label={ __( 'ldCategory' ) } value={ props.attributes.ldCategory } type='string' onChange={ ( value ) => { props.setAttributes({ ldCategory: value }); }} />
				        </PanelBody>

                        <PanelBody title={ __( 'Grid Style' ) }>
                            <TextControl label={ __( 'categoryselector' ) } value={ props.attributes.categoryselector } type='string' onChange={ ( value ) => { props.setAttributes({ categoryselector: value }); }} />
                            <TextControl label={ __( 'course_categoryselector' ) } value={ props.attributes.course_categoryselector } type='string' onChange={ ( value ) => { props.setAttributes({ course_categoryselector: value }); }} />
                            <TextControl label={ __( 'orderby' ) } value={ props.attributes.orderby } type='string' onChange={ ( value ) => { props.setAttributes({ orderby: value }); }} />
                            <TextControl label={ __( 'order' ) } value={ props.attributes.order } type='string' onChange={ ( value ) => { props.setAttributes({ order: value }); }} />
                        </PanelBody>

                    </InspectorControls>
                </Fragment>
            );
        }



        return <BlockEdit { ...props } />;
    };
}, 'addToolkitCourseDashboardSettings' );

addFilter( 'editor.BlockEdit', 'uncanny-toolkit-pro/learn-dash-my-courses', addToolkitCourseDashboardSettings );