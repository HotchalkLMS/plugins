<?php

/**
 * Register uo time
 * render it with a callback function
 */
register_block_type( 'uncanny-toolkit-pro/learn-dash-my-courses', [
	'attributes'      => [
		'user_id'                 => [
			'type'    => 'string',
			'default' => '',
		],
		'ldCategory'              => [
			'type'    => 'string',
			'default' => 'all',
		],
		'category'                => [
			'type'    => 'string',
			'default' => 'all',
		],
		'categoryselector'        => [
			'type'    => 'string',
			'default' => 'hide',
		],
		'course_categoryselector' => [
			'type'    => 'string',
			'default' => 'hide',
		],
		'orderby'                 => [
			'type'    => 'string',
			'default' => 'ID',
		],
		'order'                   => [
			'type'    => 'string',
			'default' => 'desc',
		],
	],
	'render_callback' => 'render_uo_course_dashboard',
] );

function render_uo_course_dashboard( $attributes ) {

	// Start output
	ob_start();

	// Check if the class exists
	if ( class_exists( '\uncanny_pro_toolkit\learnDashMyCourses' ) ) {
		// Check if the course ID is empty
		echo \uncanny_pro_toolkit\learnDashMyCourses::uo_course_dashboard( [
			'ld_category'             => $attributes['ldCategory'],
			'category'                => $attributes['category'],
			'categoryselector'        => $attributes['categoryselector'],
			'course_categoryselector' => $attributes['course_categoryselector'],
			'orderby'                 => $attributes['orderby'],
			'order'                   => $attributes['order'],
		] );
	}

	// Get output
	$output = ob_get_clean();

	// Return output
	return $output;
}
